Gruppo Bastianello Mattia - Cognolatto Federico - Poli Christian


Per compilare ed eseguire, da terminale nella directory laboratorio:
- cmake .
- make 
- ./progetto

( non funziona su windows :) )
