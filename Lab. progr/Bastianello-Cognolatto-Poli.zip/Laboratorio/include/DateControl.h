#ifndef DateControlh
#define DateControlh
bool myDateControl(int d, int m, int y);
#endif