#ifndef controlISBN_H
#define controlISBN_H

#include <string>

bool controlISBN(std::string str);

#endif